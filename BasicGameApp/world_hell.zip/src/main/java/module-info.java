open module com.example.basicgameapp {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;

    exports com.example.basicgameapp;
}